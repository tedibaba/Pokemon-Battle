# FIT1008/2085/1054 A1

Assignment members:

* saksham.nagpal@monash.edu
* alexey.ignatiev@monash.edu
* brendon.taylor@monash.edu
* jackson.goerner@monash.edu

TODO:

- [ ] Task 1
- [ ] Task 2
- [ ] Task 3
- [ ] Task 4
- [ ] Task 5
